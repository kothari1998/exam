# cart
php-sql shopping cart

A simple shopping cart built with PHP 5.5, SQLite database, CSS and HTML. Features of this application are:
a.	Complete Shopping Cart Features
•	User Login functionality
•	Sessions to track users profile and preference
•	Add/remove item from cart 
•	List to view all available products
•	Simple calculator to total goods added in the cart

b.	Incomplete Shopping cart Features
•	Payment integration
•	Administrator Dashboard  
•	Report generator

REFERENCES
1.	http://www.w3programmers.com/
2.	http://www.w3schools.com/php

/****************Software requirements******************************************/
•	Wamp/xampp server
•	Notepad++
/***************Installation*****************************************************/


1.	Download the source file from https://github.com/wanjugu/cart
2.	Unzip the files to ‘www’ folder of your wamp server
3.	Create a database ‘shoping_db’
4.	Import the database - shoping_db.sql
5.	Run the project on the browser (tested on chrome, firefox).



