<?php
	require("header.php");
?>
<h1>
	Tech World
</h1>
	Welcome to <strong>
	<?php
	echo $config_sitename;
	?>
	</strong> Where technology meets your needs.
	
	<?php
		require("footer.php");
	?>
